import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { User, Mail, Lock, CircleDollarSign, Building2, AlertCircle } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Input";
const RegisterPage = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState("entrepreneur");
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const getPasswordStrength = (pass) => {
    let strength = 0;
    if (pass.length >= 8) strength += 1;
    if (pass.match(/[a-z]/)) strength += 1;
    if (pass.match(/[A-Z]/)) strength += 1;
    if (pass.match(/[0-9]/)) strength += 1;
    if (pass.match(/[^a-zA-Z0-9]/)) strength += 1;
    return strength;
  };

  const strength = getPasswordStrength(password);
  
  const getStrengthColor = () => {
    if (strength === 0) return "bg-gray-200";
    if (strength <= 2) return "bg-red-500";
    if (strength === 3) return "bg-yellow-500";
    if (strength >= 4) return "bg-green-500";
  };
  
  const getStrengthLabel = () => {
    if (strength === 0) return "";
    if (strength <= 2) return "Weak";
    if (strength === 3) return "Fair";
    if (strength >= 4) return "Strong";
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    setIsLoading(true);
    try {
      await register(name, email, password, role);
      navigate(role === "entrepreneur" ? "/dashboard/entrepreneur" : "/dashboard/investor");
    } catch (err) {
      setError(err.message);
      setIsLoading(false);
    }
  };
  return <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8"><div className="sm:mx-auto sm:w-full sm:max-w-md"><div className="flex justify-center"><div className="w-12 h-12 bg-primary-600 rounded-md flex items-center justify-center"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-white"><path d="M20 7H4C2.89543 7 2 7.89543 2 9V19C2 20.1046 2.89543 21 4 21H20C21.1046 21 22 20.1046 22 19V9C22 7.89543 21.1046 7 20 7Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /><path d="M16 21V5C16 3.89543 15.1046 3 14 3H10C8.89543 3 8 3.89543 8 5V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg></div></div><h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          Create your account
        </h2><p className="mt-2 text-center text-sm text-gray-600">
          Join Business Nexus to connect with partners
        </p></div><div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md"><div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">{error && <div className="mb-4 bg-error-50 border border-error-500 text-error-700 px-4 py-3 rounded-md flex items-start"><AlertCircle size={18} className="mr-2 mt-0.5" /><span>{error}</span></div>}<form className="space-y-6" onSubmit={handleSubmit}><div><label className="block text-sm font-medium text-gray-700 mb-1">
                I am registering as a
              </label><div className="grid grid-cols-2 gap-3"><button
    type="button"
    className={`py-3 px-4 border rounded-md flex items-center justify-center transition-colors ${role === "entrepreneur" ? "border-primary-500 bg-primary-50 text-primary-700" : "border-gray-300 text-gray-700 hover:bg-gray-50"}`}
    onClick={() => setRole("entrepreneur")}
  ><Building2 size={18} className="mr-2" />
                  Entrepreneur
                </button><button
    type="button"
    className={`py-3 px-4 border rounded-md flex items-center justify-center transition-colors ${role === "investor" ? "border-primary-500 bg-primary-50 text-primary-700" : "border-gray-300 text-gray-700 hover:bg-gray-50"}`}
    onClick={() => setRole("investor")}
  ><CircleDollarSign size={18} className="mr-2" />
                  Investor
                </button></div></div><Input
    label="Full name"
    type="text"
    value={name}
    onChange={(e) => setName(e.target.value)}
    required
    fullWidth
    startAdornment={<User size={18} />}
  /><Input
    label="Email address"
    type="email"
    value={email}
    onChange={(e) => setEmail(e.target.value)}
    required
    fullWidth
    startAdornment={<Mail size={18} />}
  /><Input
    label="Password"
    type="password"
    value={password}
    onChange={(e) => setPassword(e.target.value)}
    required
    fullWidth
    fullWidth
    startAdornment={<Lock size={18} />}
  />
  {password.length > 0 && (
    <div className="mt-2 text-xs">
      <div className="flex justify-between items-center mb-1">
        <span className="text-gray-600 font-medium">Password Strength:</span>
        <span className={`font-bold ${
          strength <= 2 ? 'text-red-500' : strength === 3 ? 'text-yellow-500' : 'text-green-500'
        }`}>{getStrengthLabel()}</span>
      </div>
      <div className="flex space-x-1 h-1.5">
        {[1, 2, 3, 4, 5].map((level) => (
          <div
            key={level}
            className={`flex-1 rounded-full ${
              strength >= level ? getStrengthColor() : "bg-gray-200"
            } transition-all duration-300`}
          />
        ))}
      </div>
    </div>
  )}
  <Input
    label="Confirm password"
    type="password"
    value={confirmPassword}
    onChange={(e) => setConfirmPassword(e.target.value)}
    required
    fullWidth
    startAdornment={<Lock size={18} />}
  /><div className="flex items-center"><input
    id="terms"
    name="terms"
    type="checkbox"
    required
    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
  /><label htmlFor="terms" className="ml-2 block text-sm text-gray-900">
                I agree to the{" "}<a href="#" className="font-medium text-primary-600 hover:text-primary-500">
                  Terms of Service
                </a>{" "}
                and{" "}<a href="#" className="font-medium text-primary-600 hover:text-primary-500">
                  Privacy Policy
                </a></label></div><Button
    type="submit"
    fullWidth
    isLoading={isLoading}
  >
              Create account
            </Button></form><div className="mt-6"><div className="relative"><div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-300" /></div><div className="relative flex justify-center text-sm"><span className="px-2 bg-white text-gray-500">Or</span></div></div><div className="mt-2 text-center"><p className="text-sm text-gray-600">
                Already have an account?{" "}<Link to="/login" className="font-medium text-primary-600 hover:text-primary-500">
                  Sign in
                </Link></p></div></div></div></div></div>;
};
export {
  RegisterPage
};
